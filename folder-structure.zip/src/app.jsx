// we will render only main component here

export let App = () =>{
  return <div>
    <h1>hello from app</h1>
  </div>
}